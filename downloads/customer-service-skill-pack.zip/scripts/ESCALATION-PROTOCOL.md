# Escalation Protocol — Customer Service Skill Pack
# Eve AI Products | openclawhk.io

## 升級觸發條件

| 情況 | 行動 |
|------|------|
| 客戶連續2次道歉後仍強烈不滿 | 立即升級至人類客服 |
| 提及法律行動或監管投訴 | 立即升級 + 通知管理層 |
| 訂單金額超 HK$5,000 | 轉人類客服確認 |
| 媒體/記者查詢 | 轉公關/管理層 |
| 人身安全相關 | 立即升級 + 提供緊急聯絡 |

## 升級流程

1. **標記查詢** — 在系統中標記為「需人工跟進」
2. **告知客戶** — 使用標準升級回覆
3. **傳遞資訊** — 將對話記錄 + 客戶資料傳給人類客服
4. **追蹤結果** — 確認問題已解決後更新記錄

## 升級回覆模板

繁中：
非常抱歉您遇到呢個問題。我已將您的情況升級至我哋的高級客服團隊，
佢哋會喺 [X小時] 內直接以電話/電郵聯絡您。
感謝您的耐心等候，我哋一定會妥善處理！

English:
I sincerely apologize for the inconvenience. I've escalated your case to our senior customer service team, who will contact you directly within [X hours] by phone/email. Thank you for your patience — we'll make sure this gets resolved properly.

## 非辦公時間升級

如在非辦公時間觸發升級條件：
1. 立即記錄查詢詳情
2. 發送自動確認：「已收到您的緊急查詢，我們的團隊會在下一個工作日優先處理」
3. 如涉及安全問題，提供24小時緊急聯絡方式
