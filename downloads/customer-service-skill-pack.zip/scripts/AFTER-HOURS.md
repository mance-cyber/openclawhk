# After-Hours Auto-Reply — Customer Service Skill Pack
# Eve AI Products | openclawhk.io

## 非辦公時間設定

**辦公時間（請自訂）：** 週一至週五 9AM-6PM HKT

## 標準非辦公時間回覆

繁中版：
```
您好！感謝您聯絡 [公司名稱]。

現在係非辦公時間（辦公時間：週一至週五 9:00AM - 6:00PM 香港時間）。
您的查詢已成功記錄，我哋的團隊會在下一個工作日優先回覆您！

如有緊急情況，請電郵至：[緊急Email]

感謝您的耐心等候 🙏
[公司名稱] 客服團隊
```

英文版：
```
Hello! Thank you for contacting [Company Name].

Our office is currently closed (Business Hours: Mon-Fri 9AM-6PM HKT).
Your inquiry has been recorded and our team will respond on the next business day.

For urgent matters, please email: [Urgent Email]

Thank you for your patience 🙏
[Company Name] Customer Service Team
```

## 公眾假期回覆

繁中版（農曆新年/聖誕等長假）：
```
您好！[公司名稱] 因 [假期名稱] 休假，將於 [復工日期] 恢復正常服務。
您的查詢已記錄，復工後我哋會優先回覆您！祝您佳節愉快 🎉
```

## 設定指引

1. 在 OpenClaw Agent 設定中，加入時間判斷邏輯
2. 根據香港公眾假期更新假期回覆
3. 確保緊急聯絡 Email 有人監察
