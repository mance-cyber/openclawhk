# Customer Service Skill Pack
**Version:** 1.0
**Language:** Traditional Chinese (繁體中文) + English
**Platform:** OpenClaw
**Price:** $39 USD

---

## 包含內容 What's Included

| 檔案 | 說明 |
|------|------|
| `CUSTOMER-SERVICE-AGENT.md` | 主要客服 AI Agent 指令集 |
| `templates/FAQ-RESPONSES.md` | 60+ 常見問題標準回覆模板 |
| `templates/COMPLAINT-HANDLING.md` | 投訴處理流程 + 回覆模板 |
| `templates/ORDER-TRACKING.md` | 訂單追蹤 + 物流查詢模板 |
| `scripts/TRIAGE-WORKFLOW.md` | 查詢分類 + 優先排序系統 |
| `scripts/ESCALATION-PROTOCOL.md` | 升級機制：AI → 人類處理 |
| `scripts/AFTER-HOURS.md` | 非辦公時間自動回覆設定 |

---

## 快速開始 Quick Start

1. 將 `CUSTOMER-SERVICE-AGENT.md` 內容複製到你的 OpenClaw Agent 設定
2. 根據你的業務類型選擇適合的 templates
3. 修改品牌名稱、產品名稱、聯絡資訊
4. 測試：發送測試查詢，確認 AI 回覆符合預期
5. 上線：讓 AI Agent 24/7 處理客戶查詢

---

## 適合誰 Who Is This For

- **香港中小企**：想節省客服人手成本
- **電商賣家**：HKTVmall、Shopify、自建網店
- **服務業**：餐廳、美容院、顧問公司
- **代理商**：為客戶建立 AI 客服系統

---

## 支援 Support

問題 / 自訂需求：contact@openclawhk.io
更多產品：https://openclawhk.io
