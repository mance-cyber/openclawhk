# FAQ Response Templates — Customer Service Skill Pack
# Eve AI Products | openclawhk.io

## 訂單查詢 Order Queries

**幾時到？(When will my order arrive?)**
感謝查詢！請提供訂單號碼，我立即查詢預計到貨時間。
一般 [地區] 訂單需 [X] 個工作日送達。

**可以追蹤嗎？(Can I track my order?)**
當然！出貨後您會收到包含追蹤號碼的電郵。
請前往 [物流公司] 官網輸入號碼查詢。如未收到，請查垃圾郵箱。

**可以改地址嗎？(Can I change delivery address?)**
如訂單未出貨可以更改！請提供訂單號碼 + 新地址（含郵政編號）。
已出貨訂單的地址更改可能有額外費用。

## 退款換貨 Returns & Refunds

**我想退款 (I want a refund)**
根據我們的退款政策，購買後 [X] 日內可申請退款。
請提供：① 訂單號碼 ② 退款原因 ③ 付款截圖
退款將在 3-5 個工作日內退回原付款方式。

**收到損壞商品 (Received damaged item)**
非常抱歉！😔 請提供：訂單號碼 + 問題照片
我們將在 24 小時內安排換貨或退款，換貨不需額外費用。

## 產品查詢 Product Queries

**有試用版嗎？(Free trial?)**
我們提供 30 天退款保證，如不滿意全額退款。
如有任何問題，歡迎先問清楚再購買！

**可以開發票嗎？(Can I get an invoice?)**
購買後會自動發送電郵收據。
如需正式發票，請提供：公司名稱、商業登記號碼、發票抬頭。
1-2 個工作日內提供。

## 技術支援 Technical Support

**下載失敗 (Download failed)**
請嘗試：① 清除瀏覽器快取 ② 換瀏覽器（Chrome/Firefox）
如仍有問題，請提供訂單號碼，我們手動發送下載連結至您的電郵。

## 結尾模板 Closing Templates

**正面結尾：** 很高興能幫到您！如有其他問題，隨時聯絡我們 😊
**跟進承諾：** 同事將在 [時間] 內聯絡您。感謝您的耐心等候！
