# Content Marketing AI Skill Pack

**For Hong Kong Businesses & Creators**

Turn Claude into your dedicated content marketing team. This skill pack covers blog posts, social media, SEO writing, Cantonese copywriting, content calendars, and email marketing — all optimized for Hong Kong audiences.

---

## What's Included

| Skill | Purpose |
|-------|---------|
| `blog-posts` | Write SEO-optimized blog posts in TC Chinese + English |
| `social-media` | Create Instagram, Facebook, LinkedIn, Xiaohongshu content |
| `seo-writing` | On-page SEO optimization for HK audiences |
| `cantonese-copywriting` | Authentic Cantonese marketing copy that resonates locally |
| `content-calendar` | Plan monthly content strategy and posting schedule |
| `email-marketing` | Write email campaigns for HK subscribers |

---

## Quick Setup

### Step 1: Install Claude Code
Download from claude.ai/code — free tier works for most tasks.

### Step 2: Install Skills

Copy each skill to your Claude skills folder:
- **Mac/Linux:** `~/.claude/skills/`
- **Windows:** `C:\Users\YourName\.claude\skills\`

```bash
# Mac/Linux batch install
cp skills/blog-posts/README.md ~/.claude/skills/blog-posts.md
cp skills/social-media/README.md ~/.claude/skills/social-media.md
cp skills/seo-writing/README.md ~/.claude/skills/seo-writing.md
cp skills/cantonese-copywriting/README.md ~/.claude/skills/cantonese-copywriting.md
cp skills/content-calendar/README.md ~/.claude/skills/content-calendar.md
cp skills/email-marketing/README.md ~/.claude/skills/email-marketing.md
```

### Step 3: Use Skills

| Command | What it does |
|---------|-------------|
| `/blog-posts` | Write bilingual blog posts for HK audiences |
| `/social-media` | Create platform-specific social content |
| `/seo-writing` | Optimize any content for HK search |
| `/cantonese-copywriting` | Write authentic Cantonese marketing copy |
| `/content-calendar` | Plan your monthly content strategy |
| `/email-marketing` | Write HK-focused email campaigns |

---

## Who This Is For

- **SME owners** who need regular content but can't afford a full-time writer
- **Solopreneurs** managing their own brand
- **Marketing teams** who want to produce more content faster
- **Agencies** serving HK clients who need bilingual content

---

## Language Support

- Traditional Chinese (繁體中文) — authentic HK tone, not translated Mainland Chinese
- Cantonese colloquial (廣東話書寫體) — for social media and local platforms
- English — professional and international standard
- Bilingual — EN + ZH side-by-side output

---

## Support

Questions? Email hello@openclawhk.io or visit openclawhk.io

*OpenClaw HK — AI tools built for Hong Kong businesses*
