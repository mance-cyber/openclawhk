# E-commerce AI Assistant Skill Pack

**For HKTVmall & Shopify Sellers in Hong Kong**

This skill pack turns Claude into your dedicated e-commerce AI assistant. Install these skills to automate product listings, monitor competitors, optimize pricing, and manage inventory alerts — saving hours of manual work every day.

---

## What's Included

| Skill File | Purpose |
|------------|---------|
| `product-descriptions.md` | Write compelling HK-market product descriptions (EN + ZH) |
| `competitor-monitoring.md` | Track competitor pricing and positioning |
| `pricing-optimization.md` | Data-driven pricing recommendations |
| `inventory-alerts.md` | Low-stock alerts and reorder planning |
| `customer-replies.md` | Handle customer enquiries in Cantonese/English |
| `seo-listings.md` | Optimize product titles and tags for search |

---

## Quick Setup

### Step 1: Install Claude Code
Download from [claude.ai/code](https://claude.ai/code) — free tier works for most tasks.

### Step 2: Add Skills to Claude
Copy the skill files into your Claude skills folder:
- **Mac/Linux:** `~/.claude/skills/`
- **Windows:** `C:\Users\YourName\.claude\skills\`

Each skill is in `skills/<skill-name>/README.md`. Copy and rename:

```bash
# Mac/Linux batch install
cp skills/product-descriptions/README.md ~/.claude/skills/product-descriptions.md
cp skills/competitor-monitoring/README.md ~/.claude/skills/competitor-monitoring.md
cp skills/pricing-optimization/README.md ~/.claude/skills/pricing-optimization.md
cp skills/inventory-alerts/README.md ~/.claude/skills/inventory-alerts.md
cp skills/customer-replies/README.md ~/.claude/skills/customer-replies.md
cp skills/seo-listings/README.md ~/.claude/skills/seo-listings.md
```

### Step 3: Use Your Skills
In Claude Code, type `/product-descriptions` or `/pricing-optimization` to activate.

### Available Commands

| Command | What it does |
|---------|-------------|
| `/product-descriptions` | Write HKTVmall + Shopify listings (EN + ZH) |
| `/competitor-monitoring` | Analyze competitors and find opportunities |
| `/pricing-optimization` | Get data-driven pricing recommendations |
| `/inventory-alerts` | Calculate reorder points, draft supplier messages |
| `/customer-replies` | Write CS replies in Cantonese/English |
| `/seo-listings` | Optimize titles and tags for HK search |

---

## Platform Compatibility

| Platform | Supported Features |
|----------|-------------------|
| HKTVmall | Product listings, pricing, customer replies |
| Shopify HK | Product descriptions, SEO, inventory |
| Carousell | Quick listing copy, pricing |
| Instagram Shop | Caption copy, hashtag strategy |

---

## Language Support

All skills support:
- Traditional Chinese (繁體中文) — Hong Kong standard
- English — for international listings
- Bilingual output — EN + ZH side by side

---

## Support

Questions? Email hello@openclawhk.io or visit openclawhk.io

---

*OpenClaw HK — AI tools built for Hong Kong businesses*
