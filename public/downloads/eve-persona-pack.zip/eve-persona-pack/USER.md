# USER.md -- About Your Business and Owner

This file tells Eve about you. Eve reads this on every heartbeat. Keep it updated.

---

## Basic Information

- **Owner Name:** [YOUR NAME]
- **What to call you:** [PREFERRED NAME OR TITLE]
- **Timezone:** [YOUR TIMEZONE, e.g. GMT+8 (Asia/Hong_Kong)]
- **Primary Language:** [YOUR PREFERRED LANGUAGE, e.g. Traditional Chinese or English]

---

## Business Overview

**Company Name:** [YOUR COMPANY NAME]

**What we do:** [ONE SENTENCE DESCRIPTION]

**Who we sell to:** [WHO YOUR CUSTOMERS ARE]

**Primary market:** [MAIN GEOGRAPHY, e.g. Hong Kong, Taiwan, Global]

**Secondary markets:** [OTHER MARKETS YOU SERVE]

**Current revenue:** [APPROXIMATE MONTHLY REVENUE OR "Pre-revenue"]

---

## Products and Services

| Product/Service | Price | Status |
|----------------|-------|--------|
| [PRODUCT 1] | [PRICE] | [Active/Coming Soon/Draft] |
| [PRODUCT 2] | [PRICE] | [Active/Coming Soon/Draft] |

---

## Revenue Goals

**This month:** [MONTHLY TARGET]
**This quarter:** [QUARTERLY TARGET]
**This year:** [ANNUAL TARGET]

---

## My Preferences

**Communication style:** [How do you want Eve to talk to you? e.g. Direct and concise, always in Traditional Chinese]

**Working hours:** [Your typical available hours, e.g. 9am-6pm HKT, checking messages at 8am and 6pm]

**Report format:** [How do you want reports? e.g. Bullet points, short paragraphs, always include a revenue figure first]

**Escalation threshold:** [When should Eve ask for your input? e.g. Any decision over $100, any external communication, any new platform account]

---

## Current Priorities

[WHAT YOU MOST WANT EVE TO FOCUS ON RIGHT NOW]

Example:
- Get first paying customer within 2 weeks
- Write 10 LinkedIn posts about AI automation
- Research competitors pricing in HK market

---

## Platforms I Use

| Platform | Account Status | Purpose |
|----------|---------------|---------|
| [PLATFORM] | [Active/Need to create] | [What it is for] |

---

## Do Not Do Without Asking

- [SPECIFIC THINGS YOU ALWAYS WANT TO APPROVE]
- [TOPICS OR AREAS EVE SHOULD AVOID]

---

## Additional Context

[ANYTHING ELSE THAT HELPS EVE UNDERSTAND YOUR SITUATION AND MAKE BETTER DECISIONS]

Example:
- We are a new business, 3 months old
- My technical background: [DESCRIBE YOUR SKILLS]
- I have a budget of [AMOUNT] per month for AI API costs
- My biggest risk: [WHAT YOU MOST WANT TO AVOID]

---

*Update this file whenever your situation changes. Eve reads it on every heartbeat.*
