# ASIA-PLAYBOOK.md -- Asian Market Operations Guide

This playbook covers how to operate effectively in Hong Kong, Taiwan, and Mainland China markets. Update each section with your specific products, competitors, and strategies.

---

## Overview: Why Asia Is Different

Western marketing playbooks often fail in Asia because:

1. **Platform fragmentation** -- the major platforms differ by market (WhatsApp vs WeChat vs LINE)
2. **Language nuance** -- Traditional Chinese (HK vs TW) and Simplified Chinese are meaningfully different
3. **Trust signals** -- Asian buyers rely more on social proof, recommendations, and demonstrations
4. **Mobile-first** -- virtually all engagement happens on mobile, not desktop
5. **Community commerce** -- buying decisions are heavily influenced by community and peer recommendations

---

## Hong Kong Market

### Key Platforms
| Platform | Use Case | Priority |
|----------|---------|---------|
| HKTVmall | E-commerce product sales | High if selling physical goods |
| Facebook | Content and community | High for B2C |
| WhatsApp | Customer service and sales | High for relationship sales |
| LinkedIn | B2B outreach | Medium for business services |
| YouTube | Education and demos | Medium |
| Instagram | Visual products | Low-Medium |

### HK Content Style
- Mix of English and Cantonese is natural and expected
- Directness is valued -- get to the point quickly
- Practical over aspirational -- show how it saves time or money
- Local references build trust (mention HK-specific context)
- Avoid being preachy or overly formal

### HK Business Culture
- Relationships matter -- take time to build rapport before selling
- Credibility markers: case studies, client logos, testimonials from recognizable names
- Price sensitivity varies by segment -- premium OK if quality is clearly demonstrated
- Decision speed: SMEs can move fast, enterprises move slow

### HK Regulatory Notes
- Personal Data (Privacy) Ordinance (PDPO) governs customer data
- AMCL applies to marketing claims
- Get legal review for any health/financial product claims

### HKTVmall Product Listings
Key elements for strong listings:
1. Product title: Include brand, key feature, quantity/size
2. Main image: White background, multiple angles, lifestyle shot
3. Description: Benefits first, features second, specs last
4. Videos: 60-90 second demo videos dramatically increase conversion
5. Reviews: Priority -- get first 20 reviews before scaling ads

---

## Taiwan Market

### Key Platforms
| Platform | Use Case | Priority |
|----------|---------|---------|
| Shopee TW | E-commerce | High if selling products |
| LINE | Messaging and groups | High for community |
| Threads | Short content | High for growth |
| Instagram | Visual content | Medium |
| YouTube | Long-form education | Medium |
| PTT | Niche community | Low (for credibility) |

### TW Content Style
- Traditional Chinese but softer than HK -- less code-switching
- More emotionally driven content than HK
- Memes and kawaii aesthetics resonate
- Slower trust building but very loyal once trust is established
- LINE official accounts are important for customer retention

### TW Business Culture
- More formal initial interactions than HK
- Strong preference for Taiwanese suppliers or local presence
- Group buying and flash sales work well
- KOL (Key Opinion Leader) marketing is very effective

### Shopee Taiwan Optimization
1. Free shipping threshold: match the platform default or go slightly above
2. Flash sales: participate in Shopee-organized events for visibility
3. Product bundling: higher average order value
4. Response time: reply to messages within 1 hour for ranking boost
5. Review management: actively follow up for reviews post-purchase

---

## Mainland China Market

### Key Platforms
| Platform | Use Case | Priority |
|----------|---------|---------|
| Xiaohongshu (RED) | Discovery and review | Very High for consumer goods |
| WeChat | Relationship and CRM | Very High for any market |
| Douyin (TikTok CN) | Video commerce | High for visual products |
| Weibo | Broad awareness | Medium |
| Baidu | SEO for search | Medium |

### CN Content Style
- Simplified Chinese -- mainland tone and vocabulary
- Aspirational content works well (lifestyle, status signals)
- Key Opinion Consumer (KOC) content outperforms polished brand content
- Authenticity markers: real person photos, genuine reviews, unboxing
- Hot takes and controversies drive engagement but carry risk

### CN Platform Rules
- Xiaohongshu: content must be authentic, paid content must be disclosed
- Douyin: strong hook in first 3 seconds, strong CTA at end
- WeChat: official accounts need registration and approval
- All platforms: sensitive topics can result in account suspension without warning

### Xiaohongshu (RED) Strategy
The most effective platform for discovery in CN:

1. Content format: 300-500 word "diary" style posts with high-quality photos (9 images max)
2. Hashtags: 3-5 niche hashtags + 1-2 broader hashtags
3. Title: question or surprising statement, under 20 characters
4. Posting time: Tuesday to Thursday, 12pm-1pm or 7pm-9pm CN time
5. Engagement: respond to every comment in first 24 hours
6. KOC outreach: send product to micro-influencers (1K-10K followers) for authentic reviews

---

## Cross-Market Content Repurposing

Do not create content from scratch for each market. Repurpose:

| Source Content | HK Adaptation | TW Adaptation | CN Adaptation |
|---------------|---------------|---------------|---------------|
| English blog post | Cantonese IG caption + FB article | Mandarin Threads post + LINE message | RED note + WeChat article |
| Product demo video | Add Cantonese subtitles | Add Mandarin TW subtitles | Dubbing or CC for Douyin |
| Case study | WhatsApp-shareable format | LINE-friendly format | WeChat friendly format |

---

## Asian Market Content Calendar Template

| Day | HK | TW | CN |
|-----|----|----|-----|
| Monday | LinkedIn B2B post | Shopee flash sale prep | RED discovery post |
| Tuesday | Facebook value content | Threads engagement | Douyin video |
| Wednesday | Customer story | LINE message | WeChat article |
| Thursday | HKTVmall product update | IG product post | RED second post |
| Friday | Weekend deals FB | Shopee promotion | WeChat deal |
| Weekend | Community engagement | User-generated content | Douyin interactive |

---

## Pricing for Asian Markets

Psychological pricing patterns:
- Hong Kong: x,888 or x,999 endings work well (lucky numbers)
- Taiwan: round numbers or "buy 2 get 1" bundles are effective
- China: 99 or 199 endings are standard; lucky number 8 helps

Premium vs value positioning:
- HK: premium works if quality is demonstrated; price-sensitive for commodities
- TW: mid-market sweet spot; extreme premium is harder
- CN: tier by city (Tier 1 cities accept premium, Tier 3-4 are price-sensitive)

---

## Language Quick Reference

| Situation | HK (Cantonese/HK) | TW (Mandarin TW) | CN (Mandarin CN) |
|-----------|-------------------|-------------------|-------------------|
| Hello | 你好 / 喂 (informal) | 你好 | 你好 |
| Thank you | 多謝 / 唔該 | 謝謝 | 谢谢 |
| Sale/Discount | 優惠 / 減價 | 特價 / 折扣 | 优惠 / 折扣 |
| Buy now | 立即購買 | 立即購買 | 立即购买 |
| Limited time | 限時優惠 | 限時優惠 | 限时优惠 |
| Free shipping | 免運費 | 免運費 | 包邮 |

---

## Updates and Maintenance

This playbook should be reviewed and updated monthly. Markets change quickly, platforms update their algorithms, and what works evolves.

When you discover a new tactic that works, add it to the relevant section immediately.
