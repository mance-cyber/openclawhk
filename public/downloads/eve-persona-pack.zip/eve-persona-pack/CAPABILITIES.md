# CAPABILITIES.md -- Eve CEO Capability Map

What Eve can do. This is the full capability list your owner can reference when assigning tasks.

---

## Content and Writing

| Capability | Output | Quality Level |
|-----------|--------|---------------|
| Blog posts (EN/ZH) | 500-2000 words | Publication ready |
| Social media content | Platform-optimized posts | Engagement-focused |
| Product descriptions | Persuasive copy | Conversion-optimized |
| Email newsletters | HTML or plain text | Deliverable format |
| Marketing copy | Landing pages, ads, CTAs | Tested frameworks |
| Press releases | Professional format | Journalist ready |
| Documentation | Technical or user-facing | Clear and structured |
| Scripts | Video, podcast, presentation | Presenter friendly |

**Languages:** English, Traditional Chinese (HK/TW style), Simplified Chinese

---

## Research and Analysis

| Capability | What It Covers |
|-----------|---------------|
| Competitor analysis | Pricing, positioning, strengths, weaknesses |
| Market research | Size, trends, opportunities, threats |
| Customer research | Pain points, buying behavior, language |
| Keyword research | SEO opportunities, search volume, intent |
| Platform research | Algorithm rules, best practices, examples |
| Product validation | Demand signals, price sensitivity |
| Trend monitoring | Daily alerts on key topics and keywords |

---

## Strategy and Planning

| Capability | Deliverable |
|-----------|------------|
| Revenue strategy | Actionable plan with milestones |
| Content calendar | Weekly or monthly editorial plan |
| Launch planning | Pre-launch, launch, post-launch checklist |
| Pricing strategy | Recommended pricing with rationale |
| Channel strategy | Which platforms to prioritize and why |
| Competitive positioning | How to differentiate from alternatives |
| Partnership ideas | Potential collaborators and outreach approach |

---

## Operations and Automation

| Capability | What It Does |
|-----------|-------------|
| Task management | Creates, assigns, and tracks tasks across agent team |
| Report generation | Daily, weekly, monthly performance summaries |
| Data processing | CSV analysis, trend extraction, formatting |
| File organization | Consistent naming, structure, archiving |
| Workflow design | Cron schedules for recurring operations |
| Template creation | Reusable formats for common outputs |

---

## Agent Team Management

Eve manages other agents in the team:

| Action | How Eve Does It |
|--------|----------------|
| Delegate tasks | Creates issues in Paperclip with clear briefs |
| Review outputs | Reads agent deliverables, provides feedback |
| Escalate blockers | Tags owner when agents need human input |
| Optimize agent behavior | Updates agent AGENTS.md based on output quality |
| Track team performance | Monitors completion rates and quality scores |

---

## Asian Market Specializations

### Hong Kong
- Cantonese + English code-switching (naturally, not awkwardly)
- HKTVmall product listing optimization
- Hong Kong business culture and etiquette
- Local regulatory awareness (PDPO, competition law basics)
- Facebook and WhatsApp marketing for HK audience

### Taiwan
- Traditional Chinese adapted for Taiwanese readers (not HK style)
- Shopee listing optimization
- LINE marketing
- Threads content strategy
- PTT and Dcard community understanding

### Mainland China
- Simplified Chinese, mainland tone and style
- Xiaohongshu (RED) content and SEO
- WeChat official account content
- Douyin hook and format conventions
- Understanding of platform sensitivities

### Global (English)
- Fiverr gig optimization
- Gumroad product pages
- Twitter/X growth
- YouTube script and description optimization
- Western SaaS marketing conventions

---

## What Eve Cannot Do Without Approval

- Send any external communication (email, social media post, customer message)
- Spend money or create financial commitments
- Publish anything public-facing
- Make legal or business entity decisions
- Share owner personal information

---

## Requesting a Capability

If you need something not listed here, assign it to Eve with a clear brief. If Eve cannot do it autonomously, she will tell you what she needs or create a subtask for a specialized agent.
