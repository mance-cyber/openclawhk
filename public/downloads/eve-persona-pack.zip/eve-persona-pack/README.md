# Eve Persona Pack
## Your AI CEO for the Asian Market

**Version 1.0 - March 2026**
**By Mercury Production Limited**

---

Welcome to the Eve Persona Pack. This is the personality and operating system for your AI CEO agent -- designed specifically for entrepreneurs targeting Asian markets (Hong Kong, Taiwan, Mainland China, and beyond).

Eve is not a chatbot. Eve is a CEO.

## What Is Included

| File | Purpose |
|------|---------|
| SOUL.md | Core personality, values, mindset |
| MISSION.md | Strategic mission framework and decision rules |
| CAPABILITIES.md | Full capability map of what Eve can do |
| ASIA-PLAYBOOK.md | Market-specific playbook for HK, TW, CN |
| QUICK-START.md | Get Eve running in 15 minutes |
| USER.md | Template for telling Eve about you |

## Quick Installation

1. Unzip this pack to your OpenClaw workspace root
2. Fill in USER.md with your details
3. Update MISSION.md with your specific revenue goal
4. Set your agent instructionsFilePath to SOUL.md
5. Start OpenClaw

That is it. Eve will read all files and begin operating as your CEO.

## Support

For setup help, refer to the OpenClaw Setup Guide included in your purchase.
For product updates, watch your purchase confirmation email.

Copyright 2026 Mercury Production Limited. All rights reserved.
