# QUICK-START.md -- Get Eve Running in 15 Minutes

This guide gets you from zero to a running Eve CEO agent as fast as possible.

---

## Step 1: Fill in USER.md (3 minutes)

Open USER.md and fill in your details. The more you tell Eve about you and your business, the better she will operate.

Minimum required fields:
- Your name
- Your business description
- Your primary market (HK, TW, CN, or Global)
- Your revenue goal for this month

---

## Step 2: Update MISSION.md (3 minutes)

Open MISSION.md and:

1. Replace [YOUR REVENUE TARGET] with your actual goal (e.g. USD 1,000)
2. Replace [START DATE] with today's date
3. Replace [DEADLINE] with your deadline (e.g. 2026-04-13 for 1 month)
4. Fill in Phase 1 with your first 2-3 revenue actions

---

## Step 3: Copy Files to Workspace (2 minutes)

Copy all files from this pack to your OpenClaw workspace root:

```bash
cp -r eve-persona-pack/* ~/ai-workspace/
```

---

## Step 4: Configure Your Agent (3 minutes)

In Paperclip, update your CEO agent:

1. Set instructionsFilePath to point to SOUL.md in your workspace
2. Set the capabilities field to: "CEO, strategy, content, research, Asian markets"
3. Set model to: claude-sonnet-4-6
4. Set heartbeat intervalSec to: 3600 (1 hour)

---

## Step 5: Create Your First Task (2 minutes)

Create a simple first task to verify everything works:

```
Title: Morning brief - first day
Assign to: Eve CEO
Priority: High
Description: Run a morning brief. Review all files in the workspace (SOUL.md, MISSION.md, USER.md), summarize the business situation, and list 3 recommended actions for today. Save to temp/morning-brief-FIRST.md
```

---

## Step 6: Verify (2 minutes)

Wait for the heartbeat (or trigger manually in Paperclip). Then check:

1. Does temp/morning-brief-FIRST.md exist?
2. Does it reference your actual business details from USER.md?
3. Are the 3 recommended actions relevant to your MISSION.md goals?

If yes, Eve is working correctly. If no, check the agent run logs in Paperclip for errors.

---

## Next Steps After Setup

Once Eve is running:

1. **Set up the morning briefing cron** (9am daily) -- your daily business pulse
2. **Create your first real task** -- something that directly relates to Phase 1 of your mission
3. **Connect Telegram** -- so you can communicate with Eve from your phone
4. **Review first outputs** and update SOUL.md or AGENTS.md if needed

Refer to the OpenClaw Setup Guide for detailed instructions on all of these.

---

## Common First-Day Issues

**Eve is not responding to tasks:**
- Check that OpenClaw and Paperclip are both running
- Trigger a manual heartbeat in Paperclip
- Check agent logs for errors

**Eve output does not match my business:**
- Review USER.md -- is your business context clear?
- Check that instructionsFilePath is pointing to the correct SOUL.md
- Make sure the agent restarted after you changed configuration files

**Eve is producing output in the wrong language:**
- Add language preference to USER.md: "Default language: Traditional Chinese (HK)"
- Or specify in each task: "Respond and save output in Traditional Chinese"
